 <div class="sidebar">
        <h3>НАШІ КУРСИ</h3>
            <ul>
                <li><a href="#">Frontend CMS</a></li>
                <li><a href="#">Advanced CMS</a></li>
                <li><a href="#">Advanced PHP</a></li>
                <li><a href="#">JavaScript</a></li>
                <li><a href="#">iOS</a></li>
                <li><a href="#">Android</a></li>
                <li><a href="#">Ruby on Rails</a></li>
                <li><a href="#">Groovy & Grails</a></li>
                <li><a href="#">Java for Web</a></li>
                <li><a href="#">Project Management</a></li>
                <li><a href="#">Quality Assurance</a></li>
                <li><a href="#">Business English</a></li>
                <li><a href="#">Web & Mobile Design</a></li>
                <li><a href="#">Game Development</a></li>
            </ul>
 </div>