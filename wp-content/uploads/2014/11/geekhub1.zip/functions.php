<?php
	add_theme_support( 'menus' ); // add menus to dashboard
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-fields' );


